# from django.db import models
#
#
# # Create your models here.
# class Entity(models.Model):
#     e_name = models.TextField(verbose_name='Entity Name')
#     e_value = models.TextField(verbose_name='Entity Value')
#
#     def __str__(self):
#         return self.e_name
#
#     class Meta:
#         db_table = 'Entity'
