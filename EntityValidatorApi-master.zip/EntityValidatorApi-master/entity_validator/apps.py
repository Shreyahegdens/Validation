from django.apps import AppConfig


class ValidationApiConfig(AppConfig):
    name = 'entity_validator'
