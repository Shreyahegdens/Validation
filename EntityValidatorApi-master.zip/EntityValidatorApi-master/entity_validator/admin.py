from django.contrib import admin
# from entity_validator.models import Entity

# Register your models here.
# admin.site.register(Entity)
