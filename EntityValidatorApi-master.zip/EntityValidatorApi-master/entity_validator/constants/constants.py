class Constants:
    """
    Constant values used in the project.
    """
    staticFilled = "filled"
    staticPartial = "partially_filled"
    staticTrigger = "trigger"
    staticParams = "parameters"
    staticValue = "value"
